function logout(element) {
    element.innerText =
    "logout"
}

function alert(){
    
}